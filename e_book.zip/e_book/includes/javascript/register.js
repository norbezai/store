var flag_password = true;

function checkPassword(){
    var original_passwd = document.getElementById('passwd').value
    var confirm_passwd = document.getElementById('confirmpwd').value
    var error_p = document.getElementById('error_msg_confirmpwd')
    if(original_passwd === confirm_passwd){
        error_p.style.display = 'none';
        flag_password = true;
    }else{
        error_p.style.display = 'block';
        flag_password = false;
    }
}

function checkForm() {
    if (flag_password){
        return true;
    }
    else{
        return false;
    }
}
