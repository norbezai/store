
function showLoginModal(modal_id) {
    $(modal_id).modal('show');
}
